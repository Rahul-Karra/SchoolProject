package com.nimblix.SchoolPEPProject.Service;

public interface AdminService {
}
