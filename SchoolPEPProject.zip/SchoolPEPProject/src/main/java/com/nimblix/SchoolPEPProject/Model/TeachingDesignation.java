package com.nimblix.SchoolPEPProject.Model;

public enum TeachingDesignation {
    TEACHER,
    HOD,
    VICE_PRINCIPAL,
    PRINCIPAL
}
