package com.nimblix.SchoolPEPProject.ServiceImpl;

public class AdminServiceImpl {
}
