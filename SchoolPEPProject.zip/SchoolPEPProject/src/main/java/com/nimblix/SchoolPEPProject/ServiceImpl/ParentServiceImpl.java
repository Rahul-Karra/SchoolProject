package com.nimblix.SchoolPEPProject.ServiceImpl;

public class ParentServiceImpl {

}
