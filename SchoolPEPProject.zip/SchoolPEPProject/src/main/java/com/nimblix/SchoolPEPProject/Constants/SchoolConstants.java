package com.nimblix.SchoolPEPProject.Constants;

public class SchoolConstants {
    public static String IN_ACTIVE ="inActive" ;
    public static String STATUS_SUCCESS ="SUCCESS" ;
    public static String STUDENT ="STUDENT" ;
    public static String STUDENT_NOT_FOUND ="Student not found" ;
    public static String STATUS_FAILURE ="FAILED" ;
    public static  String STATUS ="status" ;
    public static String ACTIVE = "active";
    public static String MESSAGE ="message: " ;
    public static String USER_NOT_FOUND = "user not found: " ;
    public static final String PRESENT = "PRESENT";
    public static final String ABSENT = "ABSENT";
    public static final String TARDY = "TARDY";
}
