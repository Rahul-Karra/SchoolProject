package com.nimblix.SchoolPEPProject.Enum;

public enum NonTeachingDesignation {
    CLERK,
    ACCOUNTANT,
    LIBRARIAN,
    RECEPTIONIST,
    SECURITY,
    DRIVER,
    PEON
}
