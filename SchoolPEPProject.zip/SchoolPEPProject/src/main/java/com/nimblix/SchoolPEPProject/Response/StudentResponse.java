//package com.nimblix.SchoolPEPProject.Response;
//
//public class StudentResponse {
//
//}