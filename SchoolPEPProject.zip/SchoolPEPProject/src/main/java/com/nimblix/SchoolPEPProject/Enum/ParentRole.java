package com.nimblix.SchoolPEPProject.Enum;

public enum ParentRole {
    MOTHER,
    FATHER,
    BROTHER,
    SISTER
}
