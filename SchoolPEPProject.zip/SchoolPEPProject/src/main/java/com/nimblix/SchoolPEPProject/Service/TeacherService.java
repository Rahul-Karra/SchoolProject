package com.nimblix.SchoolPEPProject.Service;

public interface TeacherService {
}
