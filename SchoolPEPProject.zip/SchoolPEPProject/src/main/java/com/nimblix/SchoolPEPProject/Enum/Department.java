package com.nimblix.SchoolPEPProject.Enum;

public enum Department {
    MATHEMATICS,
    PHYSICS,
    SCIENCE,
    ENGLISH,
    CHEMISTRY,
    SPORTS,
    SOCIAL,
    BIOLOGY,
    COMPUTER
}
