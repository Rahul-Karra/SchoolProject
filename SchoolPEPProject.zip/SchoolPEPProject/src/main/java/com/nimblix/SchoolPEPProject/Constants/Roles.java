package com.nimblix.SchoolPEPProject.Constants;

public enum Roles {
    ADMIN,PARENTS,TEACHER,STUDENT;
}
