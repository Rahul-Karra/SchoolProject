package com.nimblix.SchoolPEPProject.Service;

public interface ParentsService {
}
