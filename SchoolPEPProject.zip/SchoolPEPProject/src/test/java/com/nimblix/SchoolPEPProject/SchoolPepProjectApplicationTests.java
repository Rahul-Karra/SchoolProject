package com.nimblix.SchoolPEPProject;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SchoolPepProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
